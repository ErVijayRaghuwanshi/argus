LOAD CSV WITH HEADERS FROM 'file:///subscriber.csv' AS row
CREATE (:Subscriber {id:row.SUBSCRIBER_ID, phone:row.PHONE_NUMBER,mno:row.MNO,city:row.CITY});